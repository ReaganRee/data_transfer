Gene_name	( no need to explain :-) right?)
Gene_id	( no need to explain :-) right?)
Mutated	(if the target gene is mutated)
Organism	( no need to explain :-) right?)
Motif	( no need to explain :-) right?)
Len	(lenght of the motif)
Experiment_description(when available)
Database (Database from where the motifs were extracted PDB: Protein data bank, C: Cisbp-RNA, R:RBPDB, S: Spliceaid-F, AEDB:ASD)
Pubmed (pubmed ID)
Experiment (type of experiment; short description)
Family (domain)
Matrix_id (linked to the file PWM.txt)
Score (Qscore refer to the paper)

The field Matrix_id refers to the pwm id that you can find in the pwm.txt file.
The position weight matrices are annotated in fasta format.
